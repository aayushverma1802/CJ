#include <iostream>

using namespace std;

struct book{
    char name[50];
    int pages;
    float chapters;
};

int main()
{
    struct book b1,b2;
    cout<<"Put data for b1"<<endl;
    cin>>b1.name;
    cin>>b1.pages;
    cin>>b1.chapters;


    cout<<"Put data for b2"<<endl;
    cin>>b2.name;
    cin>>b2.pages;
    cin>>b2.chapters;


    cout<<"Detailed information for b1  is: \n";
    cout<<b1.name<<endl;
    cout<<b1.pages<<endl;
    cout<<b1.chapters<<endl;


    cout<<"Detailed information for b2  is: \n";
    cout<<b2.name<<endl;
    cout<<b2.pages<<endl;
    cout<<b2.chapters<<endl;
    cout<<"\nHello World"<<endl;
    
    return 0;
}