#include<iostream>
#include<algorithm>
#include<functional>
using namespace std;
void printArray(int arr [],int n){
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }cout<<endl;
}
void insertion_Sort(int arr[],int n){
    int key,j=0;
    for(int i=1;i<=n;i++){
        key=arr[i];
        j=i-1;
        while ( j>=0 and key<arr[j]){
            arr[j+1]=arr[j];
            j--;
        }
        arr[j+1]=key;
    }

}
int main(){
    int arr[]={1,8,4,2,7,5,9,6,0,3};
    int n=sizeof(arr)/sizeof(arr[0]);
    insertion_Sort(arr,n);
    printArray(arr,n);
}