void findPreSuc(Node *root, Node *&pre, Node *&suc, int key)
{
    // Your code goes here
    Node ansp = root;
    Node anss = root;
    while (ansp != NULL)
    {

        if (ansp->key >= key)
        {
            suc = ansp;
            ansp = ansp->left;
        }
        else
        {
            //   ansp=ansp;
            ansp = ansp->right;
        }
    }
    while (anss != NULL)
    {

        if (anss->key >= key)
        {
            // anss=anss;
            anss = anss->left;
        }
        else
        {
            pre = anss;
            anss = anss->right;
        }
    }

}