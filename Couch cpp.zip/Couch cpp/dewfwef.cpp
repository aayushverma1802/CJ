
#include <bits/stdc++.h>
vector<int> v;
class Node{
    public:
    int data;
    Node *left;
    Node *right;
    Node()
}
class node
{
public:
    int data;
    node *next;
    node(int data)
    {
        this->data = data;
        this->next = NULL;
    }
};
class Solution
{
public:
    void inorder(Node *root)
    {
        if (root == NULL)
        {
            return NULL;
        }
        inorder(root->left);
        v.push_back(root->data);
        inorder(root->right);
    }
    node *ll(node *head, int data)
    {
        node *n = new node(data);
        node *q = head;

        while (q->next != NULL)
        {
            q = q->next;
            // n->next=NULL;
        }
        q->next = n;
        n->next = NULL;
        return head;
    }
    void flatten(Node *root)
    {
        Node *n = NULL;
        inorder(root);
        for (int i = 0; i < v.size() - 1; ++)
        {
            n = ll(root, v[i]);
        }
    }
};