#include <iostream>
using namespace std;

class Heap
{
    int arr[100];
    int size;
    Heap()
    {
        arr[0] = -1;
        size = 0;
    }
    void print()
    {
        for (int i = 1; i <= size; i++)
        {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
    void insert(int val ){
        size++;
        int index=size;
        while(index<1){
            int parent=index/2;
            if(arr[parent]<arr[index]){
                swap(arr[parent],arr[index]);
                index=parent;
            }
            else{
                return ;
            }
        }
    }
    void deletion(){
        if(size==0){
            return;
        }
        arr[1]=arr[size];
        size--;
        i =1;
        while(i<size){
            int left_Index= 2*i;
            int right_Index=2*i+1;
            if
        }

    }
};
int main()
{
    Heap h;
}