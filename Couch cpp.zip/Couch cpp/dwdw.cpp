// Server Code
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Base64;
import java.util.Scanner;

public
class server
{

public
    static void main(String[] args)
    {
        try
        {
            // Server socket setup
            ServerSocket serverSocket = new ServerSocket(12345);
            System.out.println("Server waiting for connection...");

            // Accept client connection
            Socket socket = serverSocket.accept();
            System.out.println("Client connected.");

            // Generate a random 64-bit key (8 bytes)
            byte[] keyBytes = "MySecret".getBytes(); // Replace with a secure key generation mechanism
            DESKeySpec desKeySpec = new DESKeySpec(keyBytes);
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
            SecretKey key = keyFactory.generateSecret(desKeySpec);

            // Initialize the Cipher for encryption
            Cipher encryptCipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
            encryptCipher.init(Cipher.ENCRYPT_MODE, key);

            // Initialize the Cipher for decryption
            Cipher decryptCipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
            decryptCipher.init(Cipher.DECRYPT_MODE, key);

            // Setup input and output streams
            DataInputStream inputStream = new DataInputStream(socket.getInputStream());
            DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream());

            // Receive encrypted message from client
            String encryptedMessage = inputStream.readUTF();
            System.out.println("Received encrypted message: " + encryptedMessage);

            // Decrypt the message
            byte[] decryptedBytes =
                decryptCipher.doFinal(Base64.getDecoder().decode(encryptedMessage));
            String decryptedMessage = new String(decryptedBytes);

            System.out.println("Decrypted message: " + decryptedMessage);

            // Close resources
            serverSocket.close();
            socket.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}

// Client Code
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.Base64;
import java.util.Scanner;

public
class client
{
public
    static void main(String[] args)
    {
        try
        {
            // Connect to the server
            Socket socket = new Socket("localhost", 12345);

            // Generate a random 64-bit key (8 bytes)
            byte[] keyBytes = "MySecret".getBytes(); // Replace with a secure key generation mechanism
            DESKeySpec desKeySpec = new DESKeySpec(keyBytes);
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
            SecretKey key = keyFactory.generateSecret(desKeySpec);

            // Initialize the Cipher for encryption
            Cipher encryptCipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
            encryptCipher.init(Cipher.ENCRYPT_MODE, key);

            // Initialize the Cipher for decryption
            Cipher decryptCipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
            decryptCipher.init(Cipher.DECRYPT_MODE, key);

            // Setup input and output streams
            DataInputStream inputStream = new DataInputStream(socket.getInputStream());
            DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream());

            // Take input in the form of 0s and 1s from the user
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter a binary message (0s and 1s): ");
            String binaryMessage = scanner.nextLine();

            // Encrypt the message
            byte[] encryptedBytes = encryptCipher.doFinal(binaryMessage.getBytes());
            String encryptedMessage = Base64.getEncoder().encodeToString(encryptedBytes);

            System.out.println("Encrypted message: " + encryptedMessage);

            // Send the encrypted message to the server
            outputStream.writeUTF(encryptedMessage);

            // Close resources
            socket.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
