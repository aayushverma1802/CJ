#include<stdio.h>
#include<stdlib.h>
struct Node{
    int data;
    struct Node *left ;
    struct Node *right;
}
struct Node *createNode(int data ){
    struct Node *n=(struct Node *)malloc(sizeof(struct Node));
    n->data=data;
    n->left=NULL;
    n->right=NULL;
    return n;

}
int isBST(struct Node *root){
    static struct Node *prev=NULL;
    if(root!=NULL){
        if(!isBST(root->left)){
            return 0;
        }
        if(prev!=NULL && root->data<=prev->data){
            return 0;
        }
    }
    prev=root;
    else{
        return 0;
    }
}
void insert(struct Node *root,int key){
    struct Node *prev=NULL;
    while(root!=NULL){
        prev=root;
        if(key ==root->data){
            printf("Cannot insert Already existing\n");
            return ;

        }
        else if(key<root->data){
            root=root->left;
        }
        else{
            root=root->right;
        }
        struct Node *new=createNode(key);
        if(key<prev->data){
            prev->left=new;
        }
        else{
            prev->right=new;
        }
    }
}
