#include<iostream>
#include<climits>
using namespace std;
int main(){
    //size of the array
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        //value of array data
        int m;
        cin>>m;
        arr[i]=m;
    }
    for(int i=0;i<n;i++){
        cout<<arr[i]<<endl;
    }
    cout<<"LINE***"<<endl;
    int rk=INT_MAX;

    for(int i=0;i<n;i++){
    if (arr[i]<rk){
        rk=arr[i];
    }
}
cout<<rk<<endl;

}