#include<iostream>
#include<stack>
using namespace std;
int Checker(string s){
    stack<int>sp;
    for(int i=0;i<s.length();i++){
        if(s[i]>='0'&& s[i]<=9]){
            sp.push(s[i]-'0');
        }
        else{
            int p=sp.top();
            sp.pop();
            int p2=sp.top();
            sp.pop();
            switch (s[i])
            {
            case '+':
            sp.push()
                break;
            case '-':

            
            default:
                break;
            }

        }
    }
}