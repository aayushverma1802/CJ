#include <iostream>
// #include<bits/stdc++.h>
#include <vector>
#include <queue>
#include <utility>
using namespace std;
class Solution
{
public:
    int MST(int V, vector<vector<int>> adj[])
    {
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
        vector<int> vis(V, 1e9);
        //{wt,node}
        pq.push({0, 0});
        int sum = 0;
        while (q.empty() == false)
        {
            int node = pq.top().second;
            int wt = pq.top().first;
            if (vis[node] == 1)
            {
                continue;
            }
            // add it to the next
            vis[node] = 1;
            sum += wt;
            for (auto it : adj[node])
            {
                int adjnode=it[0];
                int edw=it[1];
                if(!vis[adjNode]){
                    pq.push({edw,adjNode});
                }
            }
        }
    }
};

int main()
{

    return 69;
}