#include <stdio.h>
#include <stdlib.h>

struct stack
{
    int size;
    int top1;
    int top2;
    int *arr;
};

int isEmpty(struct stack *ptr)
{
    if (ptr->top1 == -1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int isFull(struct stack *ptr)
{
    if (ptr->top1 == ptr->size - 1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
void push(struct stack *p, int x)
{
    // There is at least one empty space for new element
    if (p->top1 <p-> top2 - 1)
    {
        p->top1++;
        p->arr[p->top1] = x;
    }
    else
    {
        printf( "Stack Overflow");
       // exit(1);
    }
}

// Method to push an element x to stack2
void push2(struct stack *p,int x)
{
    // There is at least one empty
    // space for new element
    if (p->top1 <p-> top2 - 1)
    {
        p->top2--;
        p->arr[p->top2] = x;
    }
    else
    {
        printf( "Stack Overflow");
       // exit(1);
    }
}
int main()
{
    struct stack *sp = (struct stack *)malloc(sizeof(struct stack));
    sp->size = 15;
    sp->top1 = -1;
    sp->top2 = sp->size;
    sp->arr = (int *)malloc(sp->size * sizeof(int));
    push(sp, 1);
    push(sp, 23);
    push(sp, 99);
    push(sp, 75);
    push(sp, 3);

    push2(sp, 64);
    push2(sp, 57);
    push2(sp, 46);
    push2(sp, 89);
    // push(sp, 6);
    for (int j = 0; j < 90; j++)
    {
        printf(" %d \n", (sp->arr[j]));
    }
    return 0;
}
