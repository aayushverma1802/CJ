#include<iostream>
#include<vector>
#include<bits/stdc++.h>
using namespace std;
class Solution{

    public:
    Node(int data)
{
    this->data=data;
    this->next=NULL;
    

}  
};
int main(){

    return 0;
}