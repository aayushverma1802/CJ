#include <iostream>
int main()
{
    std::cout << "What color is your bugatti?";
    return 0;
}
