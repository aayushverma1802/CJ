class Solution{
    public:
    int data;
    void morris traversal(TreeNode *node){
        Node *curr=root;
        while(curr!=NULL){
            if(!curr->left){
                ans.push_back(curr->val);
                curr=curr->right;
            }
            else{
                TreeNode *prev=curr->left;
                while(prev->right and prev->right!=curr){
                    prev =prev->rigth;
                }
                if(!prev->right){
                    prev->right=curr;
                    curr=curr->left;
                }
                else{
                    prev-right=NULL;
                     curr=curr->rigth;
                }
            }
        }
    }
}