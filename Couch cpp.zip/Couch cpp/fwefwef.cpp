
#include <iostream>
using namespace std;

int f(int x)
{
    x--;
    // cout<<x;
    return x;
}
void f1(int x)
{
    x--;
    cout << x;
}

int main()
{
    int a = 3;
    // cout << a << endl;
    cout << f(a);
     f1(a);
    // cout << a << endl;
}
