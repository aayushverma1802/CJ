#include<iostream>
#include<stream>
using namespace std;
int main(){

    return 69;
}