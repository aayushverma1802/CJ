#include<iostream>
using namespace std;
class stack{
    public:
    int *arr;
    int top;
    int size;
    stack(int size){
        this->size=size;
         arr=new int[size];
         top=-1;

    }

};
bool isEmpty(stack *t){
    if(t->top==-1){
        return true;
    }
    else{
        return false;
    }
}
bool isFull(stack *t){
    if(t->size-1==t->top){
        return true;
    }
    else{
        return false;

    }
}

void push(stack *t,int data){
    if(!isFull(t)){
        t->top++;
        t->arr[t->top]=data;
    }
    else{
        cout<<"Stack Overflow\n";
    }
}
int pop(stack * t){
    if(isEmpty(t)){
        cout<<"Stack Underflow\n";
    }
    else{
        int a=t->arr[t->top];
        t->top--;
        return a;
    }
}
int main(){
    stack *n=new stack(80);
    cout<<isEmpty(n);

    return 69;
}