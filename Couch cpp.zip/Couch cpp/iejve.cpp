#include<iostream>
#include<queue>
#include<stack>
using namespace std;
int main(){
    stack<int>s;
    queue<int>q;
    s.push(3);
    
    return 0;
}