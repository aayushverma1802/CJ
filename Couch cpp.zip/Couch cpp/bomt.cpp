#include<iostream>

using namespace std;
vector<int>bottom_View(Node *root){
    queue<pair<Node *,int>>q;
    map<int,int>m;
    q.push(make_pair(root,0));
    while(!q.empty()){
        Node *n=q.front().first;
        int hd=q.front().second;
        // if(m.find(hd)==m.end()){
        //     m[hd]=n->data;
        // }
        m[hd]=n->data;
        if(n->left){
            q.push({n->left,lvl-1});
        }
        if(n->right){
            q.push({n->right,lvl+1});
        }

    }
    vector<int>ans;

    for(auto i:m){
        ans.push_back(i);    
    }


}
int main(){


}