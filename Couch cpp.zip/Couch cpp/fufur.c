#include <stdio.h>
#include <stdlib.h>
struct Node
{
    int data;
    struct Node *next;
};
void cheems(struct Node *head, struct Node *head_2)
{
    int o1 = 0, o2 = 0;
    while (head != NULL || head_2 != NULL)
    {
        if (head != NULL)
        {
            o1 = (o1 * 10) + head->data;
            head = head->next;
        }
        if (head_2 != NULL)
        {
            o2 = (o2 * 10) + head->data;
            head_2 = head_2->next;
        }
    }
    printf("%d ",o1 * o2);
}
int main()
{
    struct Node *head = (struct Node *)malloc(sizeof(struct Node));
    struct Node *s = (struct Node *)malloc(sizeof(struct Node));
    struct Node *t = (struct Node *)malloc(sizeof(struct Node));
    struct Node *last = (struct Node *)malloc(sizeof(struct Node));
    struct Node *head_2 = (struct Node *)malloc(sizeof(struct Node));
    struct Node *s_2 = (struct Node *)malloc(sizeof(struct Node));
    struct Node *t_2 = (struct Node *)malloc(sizeof(struct Node));
    struct Node *last_2 = (struct Node *)malloc(sizeof(struct Node));
    head->data = 10;
    s->data = 11;
    t->data = 12;
    last->data = 13;
    head_2->data = 90;
    s_2->data = 91;
    t_2->data = 92;
    last_2->data = 93;
    head->next = s;
    s->next = t;
    t->next = last;
    last->next = NULL;
    head_2->next = s_2;
    s_2->next = t_2;
    t_2->next = last_2;
    last_2->next = NULL;
    cheems(head,head_2);
    return 0;
}