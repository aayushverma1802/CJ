#include<iostream>
#include<stack>
#include<queue>
using namespace std;
class Node {
    public:
    int data;
    Node *left;
    Node *right;
    Node (int data){
        this->data=data;
        this->left=NULL;
        this->right=NULL;
    }
};
void Rver_levelOrder(Node *root){
    stack <Node *>s;
    queue<Node *>q;
    q.push(root);
    while(!q.empty()){
        root=q.front();
        
        q.pop();
        s.push(root);
        if(root->right !=NULL){
            q.push(root->right );
        }
        if(root->left!=NULL){
            q.push(root->left );

        }

    }
    while(!s.empty()){
        root=s.top();
        cout<<root->data<<" ";
        s.pop();

    }


}
int main(){

    Node *root = new Node(1); 
    root->left = new Node(6); 
    root->right = new Node(2); 
    root->right->left = new Node(3); 
    //root->right->right = new Node(7); 
    Rver_levelOrder(root);
}