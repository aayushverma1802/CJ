class Solution
{
public:
    int solve(vector<int> &nums, int target, int n)
    {
        if (n == nums.size())
        {
            if (target == 0)
            {
                return 1;
            }
            return 0;
        }

        int a = solve(nums, target + nums[n], n + 1);
        int b = solve(nums, target - nums[n], n + 1);
        return a + b;
    }
    int findTargetSumWays(vector<int> &nums, int target)
    {
        return solve(nums, target, 0);
    }
};