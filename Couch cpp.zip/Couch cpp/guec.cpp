#include <iostream>
#include <stack>
#include <string.h>
using namespace std;
class Solution
{
public:
    bool toCheck(string x)
    {
        stack<char> s;
        for (int i = 0; i < x.length(); i++)
        {
            if (x[i] == '(' or x[i] == '[' or x[i] == '{')
            {
                s.push(x[i]);
            }
            else if (x[i] == ')' or x[i] == ']' or x[i] == '}')
            {
                if (s.empty())
                {
                    return false;
                }

                if ((s.top() == '(' && x[i] == ')') || (s.top() == '{' && x[i] == '}') || (s.top() == '[' && x[i] == ']'))
                {
                    s.pop();
                }
                return false;
            }
            else{
                return false;
            }
        }
        if (s.empty())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
};
int main()
{
    Solution s;
    cout << s.toCheck("([]})");

    return 0;
}