#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *left;
    Node *right;
    Node(int data)
    {
        this->data = data;
        this->left = NULL;
        this->right = NULL;
    }
};
bool Iterative_Search(Node *root, int key)
{
    if (root->data == key)
    {
        return true;
    }
    else if (root->data < key)
    {
        root = root->right;
    }
    else
    {
        root = root->left;
    }
    return false;
}
void InOrder(Node *root)
{
    if (root != NULL)
    {
        InOrder(root->left);
        cout << root->data << " ";
        InOrder(root->right);
    }
}
int main()
{
}
