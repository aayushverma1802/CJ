#include<iostream>
#include<climits>
using namespace std;
int main(){
    //size of the array
    int n;
    cin>>n;
    int arr[n];
    //input for the array 
    for(int i=0;i<n;i++){
        int m;
        cin>>m;
        arr[i]=m;
    }int temp=INT_MIN;
    //to find the max element from the array
    for(int i=0;i<n;i++){
        
        if(arr[i]>temp){
            temp=arr[i];
        }
       
    }
    cout<<temp;
    

    //Display the array
    // for(int i=0;i<n;i++){
    //     cout<<arr[i]<<endl;
    // }



}