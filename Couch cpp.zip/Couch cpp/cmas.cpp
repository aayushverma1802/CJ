#include <iostream>
#include <vector>
#include <utility>
#include <algorithm>
using namespace std;

// #include<bits/stdc++.h>

class Solution
{
public:
    const bool cmp()(pair<int, int> a, pair<int, int> b)
    {
        return (a.second < b.second);
    }
} int main()
{
    // Solution *obj;
    pair<int,int>v;
    // for (int i = 0; i < 5; i++)
    // {
    //     int x, y;
    //     cin >> x >> y;
    //     v.push_back(make_pair(x, y));
    // }
    // for (int i = 0; i < v.size(); i++)
    // {
    //     cout << v[i].first << " " << v[i].second << endl;
    // }
 
    // cout << endl;
    // for (int i = 0; i < v.size(); i++)
    // {
    //     cout << v[i].first << " " << v[i].second << endl;
    // }

    return 69;
}