#include<iostream>
#include<stdio.h>
#include<vector>

using namespace std;

void printArr(int a[],int n){
    for (int k = 0; k < n; k++){
        printf("%d ",a[k]);
    }
    printf("\n");
}
void inseertion_sort(int a[],int n){
    int j,key;
    for (int i=1;i<=n-1;i++){
        key=a[i];
        j=i-1;
        while(j>=0&&a[j]>key){
            a[j+1]=a[j];
            j--;
        }
        a[j+1]=key;
    }
}
int main(){
    int a[]={-1, 2, -2, -5, 4, 0}; 
    int n=6;
    for(int i=0;i<6;i++){
        arr[i]=a[i+1];
    }
    inseertion_sort(a,n);
    printArr(a,n);
    return 69;
}