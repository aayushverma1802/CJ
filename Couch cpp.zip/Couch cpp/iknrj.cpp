#include<iostream>
#include<vector>
using namespace std;
class Node{
    public:
    int data;
    Node *left;
    Node *right;
    Node(int d){
        data=d;
        left=NULL;
        right=NULL;
    }
};
class cmp{
    public:
    bool operator()(Node *a,Node *b){
        return a->data>b->data;
    }
};
class Ans{
    public:
    
}
int main(){

}