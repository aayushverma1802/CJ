#include<iostream>
#include<vector>
using namespace std;
void printnn(vector<int>&arr){
    for(int i=0;i<arr.size();i++){
        cout<<arr[i]<<" ";
    }
}
void insertion(vector<int>&arr){
    int n=arr.size();
    int key;
    int j;

    for(int i=1;i<n;i++){
        key=arr[i];
        j=i-1;
        while( j>=0 and arr[j]>key){
            arr[j+1]=arr[j];
            j--;

        }
        arr[j+1]=key;
    }
}
int main(){
    vector<int>v{12,5,7,456,3,65,7687};
    insertion(v);
    printnn(v);
}