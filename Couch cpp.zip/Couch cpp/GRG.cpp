#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>

using namespace std;

// Function to count the frequency of each symbol in the array
unordered_map<char, int> countSymbols(const vector<char>& arr) {
    unordered_map<char, int> symbolCount;
    for (char symbol : arr) {
        symbolCount[symbol]++;
    }
    return symbolCount;
}

// Function to merge two symbol arrays
vector<char> merge(const vector<char>& leftArr, const vector<char>& rightArr) {
    vector<char> mergedArr;
    mergedArr.reserve(leftArr.size() + rightArr.size());
    mergedArr.insert(mergedArr.end(), leftArr.begin(), leftArr.end());
    mergedArr.insert(mergedArr.end(), rightArr.begin(), rightArr.end());
    return mergedArr;
}

// Function to recursively sort the symbol array based on frequency of occurrences
vector<char> sortSymbols(const vector<char>& arr) {
    // Base case: If the array is empty or has only one element, it is already sorted
    if (arr.size() <= 1) {
        return arr;
    }

    // Count the frequency of each symbol in the array
    unordered_map<char, int> symbolCount = countSymbols(arr);

    // Divide the array into two halves
    int mid = arr.size() / 2;
    vector<char> leftHalf(arr.begin(), arr.begin() + mid);
    vector<char> rightHalf(arr.begin() + mid, arr.end());

    // Sort the two halves recursively
    vector<char> sortedLeft = sortSymbols(leftHalf);
    vector<char> sortedRight = sortSymbols(rightHalf);

    // Merge the sorted halves
    vector<char> merged = merge(sortedLeft, sortedRight);

    // Sort the merged array based on symbol frequency
    sort(merged.begin(), merged.end(), [&](char a, char b) {
        return symbolCount[a] > symbolCount[b];
    });

    return merged;
}

int main() {
    vector<char> symbols = {'*', '$', '*', '+', '*', '-', '-', '+', '-', '*'};

    vector<char> sortedSymbols = sortSymbols(symbols);

    // Print the sorted symbols
    for (char symbol : sortedSymbols) {
        cout << symbol << " ";
    }
    cout << endl;

    return 0;
}
