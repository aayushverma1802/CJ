#include <iostream>
#include <string>
using namespace std;

string replaceRepeatedSubstrings(string s) {
    string result = "";
    int i = 0;
    while (i < s.length()) {
        if (i + 1 < s.length() && s[i] == s[i + 1]) {
            result += "1";
            i += 2;
        } else {
            result += s[i];
            i++;
        }
    }
    return result;
}

int main() {
    string s;
    cin>>s;
    cout << replaceRepeatedSubstrings(s) << endl;
    return 0;
}
