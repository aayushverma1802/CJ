#include <iostream>
#include <vector>
#include <algorithm>
#include <functional>
using namespace std;
class Node
{
public:
    int data;
    Node *left;
    Node *right;
    Node(int data)
    {
        this->data = data;
        this->left = NULL;
        this->right = NULL;
    }
    Node *Insert(Node *tree, int key)
    {
        if (tree == NULL)
        {
            Node *n = new Node(key);
            return n;
        }
        else if (tree->data > key)
        {
            tree->left = Insert(tree->left, key);
        }
        else if (tree->data < key)
        {
            tree->right = Insert(tree->left, key);
        }
    }
    void inOrder(Node *root)
    {
        if (root == NULL)
        {
            return;
        }
        inOrder(root->left);
        cout << root->data << " ";
        inOrder(root->right);
    }
};
int main()
{
    Node *obj;
    Node *n = NULL;

    n = obj->Insert(n, 10);
    n = obj->Insert(n, 90);
    n = obj->Insert(n, 5);
    obj->inOrder(n);
    return 0;
}