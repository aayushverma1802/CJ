vector<int>getInoder(TreeNode *root){
    vector<int>inorder;
    TreeNode *curr=root;
    while(curr!=NULL){
        if(curr->left){
            inorder.push_back(curr->left);
            curr=curr->right;

        }
        else{
            TreeNode *prev=root->right;
            while(prev->right and prev->right!=curr){
                prev=prev->right;
            }
            if(prev->right==NULL){
                prev->right=curr;
                curr=curr->left;
            }
            else{
                prev->right=NULL;

            }
        }
    }
}