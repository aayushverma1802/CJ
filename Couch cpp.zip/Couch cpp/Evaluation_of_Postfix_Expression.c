#include <stdio.h>
#include <stdlib.h>
struct Node
{
    int top;
    int size;
    int *arr;
};
int isEmpty(struct Node *ptr)
{
    if (ptr->top == -1)
    {
        // printf("Stack is Empty");
        return 1;
    }
    else
    {
        return 0;
    }
}
int isFull(struct Node *ptr)
{
    if (ptr->top == ptr->size - 1)
    {
        // printf("Stack Overfllow");
        return 1;
    }
    else
    {
        // printf("Stack Underflow");
        return 0;
    }
}
void push(struct Node *ptr, int data)
{
    if (!isFull(ptr))
    {
        ptr->top++;
        ptr->arr[ptr->top] = data;
    }
    else
    {
        printf("Stack Overflow\n");
    }
}
void pop(struct Node *ptr)
{
    if (!isEmpty(ptr))
    {
        ptr->top--;
    }
    else
    {
        printf("Stack Underflow\n");
    }
}
int main()
{
    struct Node *sp;
    sp->size = 80;
    sp->arr = (int *)malloc(sizeof(int) * (sp->size));
    sp->top = -1;
    push(sp, 1);
    push(sp, 23);
    push(sp, 99);
    push(sp, 75);
    push(sp, 3);
    push(sp, 64);
    push(sp, 57);
    push(sp, 46);
    push(sp, 89);
    push(sp, 6);
    // Printing values from the stack
    for (int j = 0; j <sp->top+1; j++)
    {
        printf("%d \n", sp->arr[j]);
    }
}