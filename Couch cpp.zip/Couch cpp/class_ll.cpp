#include<iostream>
using namespace std;
class Node{
    public:
    int data;
    Node *next;
    Node(int data){
        this->data=data;
        next=NULL;
    }
};
void Linked_list_traversal(Node * head){
    while(head!=NULL){
        cout<<head->data;
        head=head->next;
    }

}
int main(){
    class Node a(54);
    Linked_list_traversal(a);


}