#include<iostream>
using namespace std;
int main(){
    TreeNode *createMap(map<TreeNode *,TreeNode>&nodetoparent,TreeNode *root,int target ){
        TreeNode *res=nullptr;
        queue<TreeNode *>q;
        q.push(root);
        nodetoparent[root]=NULL;
        while(!q.empty()){
            TreeNode *front=q.front();
            q.pop();
            if(front->val==target){
                res=front;

            }
            if(front-val==target){
                nodetoparent(front->val)=front;
                q.push(front->left);
            }
            if(front->right){
                nodetoparent[front->right]=front;
                q.push(front->right);

            }
        }
    }
    return 0;
}