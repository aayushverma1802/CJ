#include<iostream>

int main(){
    return 0;
}STDIN_FILENOf


fwidef
wef

WEOFwe
fwide 
WEOFwef
wf
 WEOFwefwef
 we
 f fweewf