#include <iostream>
#include<list>
using namespace std;
int main()
{
    list<int>l1;
    l1.push_back(23);
    

} 
