#include<stdio.h>
#include<stdlib.h>
struct Node {
    int data;
    struct Node *left;
    struct Node *right;
};
struct Node *createNode(int data){
    struct Node *n=(struct Node *)malloc(sizeof(struct Node  ));
    n->data=data;
    n->left=NULL;
    n->right=NULL;
    return n;

}
void insert(struct Node *root,int key){
    struct Node *prev=NULL;
    while(root!=NULL){
        prev=root;
        if(root->data){
            printf("Cannot Insert %d\nElement Already existing\n.");
            return ;

        }
        else if(key<root->data){
            root=root->left;
        }
        else {
            root=root->right;
        }
        struct Node *new=createNode(key);
        if(key<prev->data){
            prev->left=new;

        }
        else{
            prev->left=new;
        }
    }
}
int main(){

}
