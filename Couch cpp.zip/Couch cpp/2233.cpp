#include <iostream>
#include <string>

using namespace std;

string replaceRepeatedSubstrings(string s) {
    int n = s.length();
    for (int i = 1; i < n; i++) {
        int j = i;
        while (j < n && s[j] == s[j-1]) {
            j++;
        }
        if (j - i > 1) {
            s.replace(i, j-i, "1");
            n = s.length();
        }
    }
    return s;
}

int main() {
    string s;
    cin>>s;
    string result = replaceRepeatedSubstrings(s);
    cout << result << endl; // Output: 1111ab1a
    return 0;
}