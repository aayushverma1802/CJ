
#include <vector>
#include <iostream>
using namespace std;

int main()
{

    vector<int> arr{234, 5, 35, 6, 56, 3};
    for (auto &x : arr)
    {
        cout << x << " ";
    }
}