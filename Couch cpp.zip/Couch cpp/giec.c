#include <stdio.h>
#include <stdlib.h>
struct Node
{
    int data;
    struct Node *next;
};
void linkedListTraversal(struct Node *ptr)
{
    while (ptr != NULL)
    {
        printf("Element: %d\n", ptr->data);
        ptr = ptr->next;
    }
}
void multi(struct Node head,struct Node * head_2){
    struct Node *ptr=head;
    struct Node *p=head_2;
    int k=0,
    while(ptr!=NULL){
        for(int i=0;i<i++){
            
        }
    }
}
int main()
{
    struct Node *head = (struct Node *)malloc(sizeof(struct Node));
    struct Node *s = (struct Node *)malloc(sizeof(struct Node));
    struct Node *t = (struct Node *)malloc(sizeof(struct Node));
    struct Node *last = (struct Node *)malloc(sizeof(struct Node));
    // Entering the Data;
    head->data = 9;
    s->data = 4;
    t->data = 6;
    last->data = 14;
    // Connection of Linked List;
    head->next = s;
    s->next = t;
    t->next = last;
    last->next = NULL;
    // New linked list;
    struct Node *h1 = (struct Node *)malloc(sizeof(struct Node));
    struct Node *h2 = (struct Node *)malloc(sizeof(struct Node));
    struct Node *h3 = (struct Node *)malloc(sizeof(struct Node));
    // adding of the data;
    h1->data = 8;
    h2->data = 4;
    h3->data = 1;
    // Connection the linked list;
    h1->next = h2;
    h2->next = h3;
    h3->next = NULL;
    return 69;
}