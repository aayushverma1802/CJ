#include <iostream>
#include <string>
#include<vector>
#include<string.h>
using namespace std;

string replace_repeated_substrings(string s) {
  // Initialize a list to store the replaced substrings.
  vector<string>replaced_substrings;
  // Iterate over the characters in the string.
  for (int i = 0; i < s.length(); i++) {
    // Check if the current character is the same as the next character.
    if (s[i] == s[i + 1]) {
      // If it is, add the current substring to the list of replaced substrings.
      replaced_substrings.push_back(s.substr(i, 2));
    }
  }

  // Iterate over the replaced substrings.
  for (string substring : replaced_substrings) {
    // Replace all occurrences of the substring in the string with the character '1'.
    s = s.replace(substring, "1");
  }

  return s;
}

int main() {
  // Get the input string from the user.
  string s;
  cin >> s;

  // Replace all repeated substrings in the string.
  string new_s = replace_repeated_substrings(s);

  // Print the new string.
  cout << new_s << endl;

  return 0;
}
