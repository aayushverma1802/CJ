class Solution
{

public:
    int orangesRotting(vector<vector<int>> &grid)
    {
        int n = grid.size();
        int m = grid[0].size();
        queue<pair<pair<int, int>, int>> q;
        // we will store the time
        // we will store the row
        // we will store the column;
        vis[n][m];
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
            {
                if (grid[i][j] == 2)
                {
                    vis[i][j] = 2;
                    q.push({{i, j}, 0});
                }
                else
                {
                    vis[i][j] = 0;
                }
            }
        }
        int tm = 0;
        int drow = {-1, 1, 0, 0};
        int dcol = {0, 0, -1, 1};
        while (q.empty() == false)
        {
            int f = q.first.first;
            int s = q.second.second;
            int t = q.second;
            tm = max(t, tm);
            q.pop();
            for (int i = 0; i < 4; i++)
            {
                int row = drow[i] + f;
                int col = dcol[i] + s;
                if (row > 0 and col > 0 and row < n and col < n and vis[row][col] != 2 and grid[row][col] == 1)
                {
                    q.push({row, col}, tm + 1);
                    vis[row][col] = 2;
                }
            }
        }
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
            {
                if (vis[i][j] != 2 and grid[i][j] == 1)
                {
                    return -1;
                }
            }
        }
        return tm;
    }
}