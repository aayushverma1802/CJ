#include <iostream>
#include <string>
#include <unordered_set>

std::string replace_repeated_substrings(const std::string& s) {
    std::string result = s;
    std::unordered_set<std::string> replaced;

    for (size_t i = 0; i < result.length() - 1; ++i) {
        size_t j = i + 1;
        while (j < result.length() && result[i] == result[j]) {
            ++j;
        }

        if (j - i > 1) {
            std::string sub = result.substr(i, j - i);
            if (replaced.find(sub) == replaced.end()) {
                std::string replacement = std::to_string(replaced.size() + 1);
                result.replace(i, j - i, replacement);
                replaced.insert(sub);
            }
        }
    }

    return result;
}

int main() {
    std::string s = "abababaa";
    std::string final_string = replace_repeated_substrings(s);
    std::cout << final_string << std::endl;  // Output: "1111ab1a"
    return 0;
}
