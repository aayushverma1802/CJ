#include<iostream>
using namespace std;
class Node{
    public:
    int data;
    Node *left;
    Node *right;
    Node(int data){
        this->data=data;
        this->left=NULL;
        this->right=NULL;
    }
    
};
void Linked_List_traversal(Node * head){
    Node *n=head;
    while(n!=NULL){
        cout<<n->data<<" ";
       // printf("\n");
        n=n->next;

    }
}
int main(){
    Node *n=new Node (234);
    
    Linked_List_traversal(n);

}