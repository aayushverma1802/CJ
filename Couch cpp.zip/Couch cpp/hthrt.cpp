#include <iostream>
using namespace std;

void arrangePartialArray(int A[], int N)
{
    for (int i = 0; i < N - 1; i++)
    {
        if (A[i] > A[i + 1])
        {
            int temp = A[i];
            A[i] = A[i + 1];
            A[i + 1] = temp;

            if (i > 0 && A[i - 1] > A[i])
            {
                // If the previous element is still greater, swap until it's in the correct position
                while (i > 0 && A[i - 1] > A[i])
                {
                    temp = A[i];
                    A[i] = A[i - 1];
                    A[i - 1] = temp;
                    i--;
                }
            }
        }
    }
}

int main()
{
    int A[] = {3, 10, 4, 11, 5, 12, 6};
    int N = sizeof(A) / sizeof(A[0]);

    cout << "Partial Array before arranging: ";
    for (int i = 0; i < N; i++)
    {
        cout << A[i] << " ";
    }
    cout << endl;

    arrangePartialArray(A, N);

    cout << "Partial Array after arranging: ";
    for (int i = 0; i < N; i++)
    {
        cout << A[i] << " ";
    }
    cout << endl;

    return 0;
}