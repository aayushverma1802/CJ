import java.util.Scanner;
public
class LRCMechanism
{
public
    static String calculateParity(String[] dataBits)
    {
        StringBuilder parity = new StringBuilder();
        int numBits = dataBits.length;
        for (int i = 0; i < numBits; i++)
        {
            int parityBit = 0;
            for (int j = 0; j < numBits; j++)
            {
                if (dataBits[j].equals("1"))
                {
                    parityBit ^= 1;
                }
            }
            parity.append(parityBit);
        }
        return parity.toString();
    }
public
    static String generateOriginalBit(String[] dataBits, String parity)
    {
        StringBuilder originalBit = new StringBuilder();
        for (String dataBit : dataBits)
        {
            originalBit.append(dataBit);
        }
        originalBit.append(parity);
        return originalBit.toString();
    }
public
    static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of data bits: ");
        int numBits = scanner.nextInt();
        scanner.nextLine();
        String[] dataBits = new String[numBits];
        for (int i = 0; i < numBits; i++)
        {
            System.out.print("Enter data bit " + (i + 1) + ": ");
            dataBits[i] = scanner.nextLine();
        }
        String parity = calculateParity(dataBits);
        String originalBit = generateOriginalBit(dataBits, parity);
        System.out.println("Original Bit (LRC): " + originalBit);
    }
}