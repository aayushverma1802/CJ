#include<stdio.h>
#include<stdlib.h>
struct Node{
    int data;
    struct Node *next;
    // struct Node *r;
    // struct Node *f;
}
struct Node *r=NULL;
struct Node  *f= NULL;
void enqueue(struct Node *ptr,int data){
    struct Node *n=(struct Node *)malloc(sizeof(struct Node ));
    if(n==NULL){
        printf("Queue is full\n");
    }
    else {
        n->data=data;
        if(f==NULL){
            f=r=n;
        }
        else{
            r->next=n;
            r=n;
        }
    }
}
