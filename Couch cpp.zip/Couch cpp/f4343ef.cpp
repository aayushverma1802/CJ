#include <iostream>
#include <string>
#include <bitset>
using namespace std;
// Function to identify the class name (if classful addressing)
string identifyClass(const string &ipAddress)
{
    int firstByte = stoi(ipAddress.substr(0, ipAddress.find('.')));
    if (firstByte >= 0 && firstByte <= 127)
    {
        return "Class A";
    }
    else if (firstByte >= 128 && firstByte <= 191)
    {
        return "Class B";
    }
    else if (firstByte >= 192 && firstByte <= 223)
    {
        return "Class C";
    }
    else if (firstByte >= 224 && firstByte <= 239)
    {
        return "Class D";
    }
    else if (firstByte >= 240 && firstByte <= 255)
    {
        return "Class E";
    }
    else
    {
        return "Unknown Class";
    }
}
// Function to calculate the network ID
string calculateNetworkID(const string &ipAddress, const string &subnetMask)
{
    string networkID;
    for (int i = 0; i < 32; i++)
    {
        networkID += to_string((ipAddress[i] - '0') & (subnetMask[i] - '0'));
        if (i % 8 == 7)
        {
            networkID += '.';
        }
    }
    return networkID;
}
// Function to calculate the host ID
string calculateHostID(const string &ipAddress, const string &subnetMask)
{
    string hostID;
    for (int i = 0; i < 32; i++)
    {
        hostID += to_string((ipAddress[i] - '0') & (~(subnetMask[i] - '0')));
        if (i % 8 == 7)
        {
            hostID += '.';
        }
    }
    return hostID;
}
// Function to calculate the subnet mask
string calculateSubnetMask(const string &subnetMaskBits)
{
    string subnetMask;
    for (int i = 0; i < 32; i++)
    {
        subnetMask += (i < stoi(subnetMaskBits)) ? '1' : '0';
        if (i % 8 == 7)
        {
            subnetMask += '.';
        }
    }
    return subnetMask;
}
// Function to calculate the total number of address spaces
unsigned long long calculateTotalAddressSpaces(int subnetMaskBits)
{
    return (1ULL << (32 - subnetMaskBits));
}
// Function to calculate the first address
string calculateFirstAddress(const string &networkID)
{
    return networkID.substr(0, networkID.find_last_of('.') + 1) + "1";
}
// Function to calculate the last address
string calculateLastAddress(const string &networkID, int subnetMaskBits)
{
    string lastAddress = networkID.substr(0, networkID.find_last_of('.') + 1);
    unsigned long long numAddresses =
        calculateTotalAddressSpaces(subnetMaskBits);
    unsigned long long lastHost = numAddresses - 2;
    lastAddress += to_string(lastHost / 16777216) + '.';           // (2^24)
    lastAddress += to_string((lastHost % 16777216) / 65536) + '.'; // (2^16)
    lastAddress += to_string((lastHost % 65536) / 256) + '.';      // (2^8)
    lastAddress += to_string(lastHost % 256);
    return lastAddress;
}
// Function to calculate the total number of addresses
unsigned long long calculateTotalAddresses(int subnetMaskBits)
{
    return calculateTotalAddressSpaces(subnetMaskBits) - 2;
}
int main()
{
    string ipAddress;
    string ipAddressType;
    int numSubnetworks;
    cout << "Enter the IP address: ";
    cin >> ipAddress;
    cout << "Enter the IP address type (IPv4 or IPv6): ";
    cin >> ipAddressType;
    cout << "Enter the number of subnetworks: ";
    cin >> numSubnetworks;
    string subnetMaskBits;
    if (ipAddressType == "IPv4")
    {
        cout << "Enter the subnet mask bits (e.g., 24 for Class C subnet): ";
        cin >> subnetMaskBits;
    }
    else
    {
        subnetMaskBits = "64"; // Default subnet mask bits for IPv6
    }
    string subnetMask = calculateSubnetMask(subnetMaskBits);
    string networkID = calculateNetworkID(ipAddress, subnetMask);
    string hostID = calculateHostID(ipAddress, subnetMask);
    string className = identifyClass(ipAddress);
    unsigned long long totalAddressSpaces =
        calculateTotalAddressSpaces(stoi(subnetMaskBits));
    string firstAddress = calculateFirstAddress(networkID);
    string lastAddress = calculateLastAddress(networkID,
                                              stoi(subnetMaskBits));
    unsigned long long totalAddresses =
        calculateTotalAddresses(stoi(subnetMaskBits));
    cout << "\nResults:" << endl;
    cout << "Class Name: " << className << endl;
    cout << "Network ID: " << networkID << endl;
    cout << "Host ID: " << hostID << endl;
    cout << "Subnet Mask: " << subnetMask << endl;
    cout << "Total Number of Address Spaces: " << totalAddressSpaces << endl;
    cout << "First Address: " << firstAddress << endl;
    cout << "Last Address: " << lastAddress << endl;
    cout << "Total Number of Addresses: " << totalAddresses << endl;
    return 0;
}