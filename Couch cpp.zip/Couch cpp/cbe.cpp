#include <iostream>
#include <map>
#include <vector>
using namespace std;
int main()
{
    map<int, int> m;
    int arr[] = {-1, 2, -2, -5, 4, 0};
    int n = sizeof(arr) / sizeof(arr[0]);

    for (int i = 0; i < n; i++)
    {
        if (i % 2 == 0)
        {
            m.insert({i, arr[i]});
        }
    }

for(int i=0;i<n;i++)
    {
        arr[i.first] = i.second;
		//n--;
    }
    for (int k = 0; k < n; k++)
    {
        printf("%d ", arr[k]);
    }
    return 0;
}

