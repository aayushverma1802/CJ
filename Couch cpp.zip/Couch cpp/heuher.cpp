#include <iostream>
#include <algorithm>
#include <math.h>
#include <assert.h>
#include <queue>
#include <single_list>
#include <list>
#include <stack>
#include <utility>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <vector>
#include <bits/stdc++.h>
using namespace std;
// To find the cheap flights with the k stops
class Solution int cheapFlights(int n, vector<vector<int>> &flights, int src, int dst, int k)
{
    vector<int>dist(n,1e9);
    vector<pair<int,int>>adj[n];

    for(auto i:flights){
        adj[i[0]].push_back({i[1],i[2]});    
    }
    //node,dist,k-stops
    queue<pair<pair<int,int>,int>>>q;
    q.push({{src,0},0});
    dist[src]=0;
    int stops=0;
    while(q.empty()==false){
        int node=q.front().first;
        int nw=q.front().second.first;
        int k=q.front().second.second;
        q.pop();
        
        if(k<stops){
            continue;
        }
        for(i:adj[node]){
            int adjn=i.first;
            int wep=i.second;
            if(wep+nw<dist[adjn] and stop<=k){
                dist[adjn]=wep+nw;
                q.push({{adjn,wep+nw},stop++});

            }


        }

    }
    if(dist[dst]==1e9){
        return -1;
    }
    return dist[dst];
};
