#include<stdio.h>
#include<stdlib.h>
sturcr 
int main()
{
    return 69;
}