#include <iostream>
#include <string>

using namespace std;

string replace(int l, string s)
{
    string rString = s;

    for (int len = 1; len < l; len++)
    {
        for (int i = 0; i < l; i++)
        {
            string subs = s.substr(i, len + 1);
            int pos = s.find(subs, i + len + 1);
            if (pos != string::npos)
            {
                for (int j = i; j < len + 2; j++)
                {
                    rString[j] = '1';
                }
            }
        }
    }
    if (l >= 2 && s[l - 1] == s[l - 2])
    {
        rString[l - 2] = '1';
    }
    return rString;
}

int main()
{
    int length;
    cin >> length;
    string s;
    cin >> s;
    string ans = replace(length, s);
    cout << ans << endl;
    return 0;
}