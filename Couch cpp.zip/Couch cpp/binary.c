#include<stdio.h>
#include<stdlib.h>
struct Node {
    int data;
    struct Node *left;
    struct Node *right;
};
struct Node *createNode(int data){
    struct Node *n;
    //Linking the node
    n->data=data;
    n->left=NULL;
    n->right=NULL;
    //Entering the data

    
}
int main(){
   // struct Node *p1=(struct Node *)malloc(sizeof(struct Node));
   struct Node *p=createNode(34);
   struct Node *p2=createNode(43);
   struct Node *p3=createNode(454);
   p->left=p2;
   p->right=p3;
   

    createNode(34);

}
