#include <stdio.h>
#include <stdlib.h>
struct Node
{
    int top;
    int size;
    int *arr;
};
int isEmpty(struct Node *p)
{
    if (p->top = -1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int isFull(struct Node *p)
{
    if (p->top = p->size - 1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
void push(struct Node *p,int data){
    if(isFull(p)){
        printf("Stack Overflow\n");
    }
    else{
        p->top++;
        p->arr[p->top]=data;
    }
}
int main(){
    struct Node *p;
    p->arr=(int *)malloc(p->size*sizeof(int));
    p->top=-1;
    p->size=5;
    push(p,32);
    for(int i=0;)
}