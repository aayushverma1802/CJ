#include<iostream>
using namespace std;
int main(){
    int arr[10];
    for(int i=0;i<10;i++){
        cin>>arr[i];
    }
    for(int i=0;i<10;i++){
        //cout<<arr[i];
    }
    int sum=0;
    
    for(int i=0;i<10;i++){
        sum = sum + arr[i];
    }
    cout<<sum<<endl;
    return 0;
    
}