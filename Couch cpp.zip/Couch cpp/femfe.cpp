#include <iostream>
#include <vector>
#include <queue>
using namespace std;
const int N = 1e7;
vector<int> adj[N];
bool vis[N];
int main()
{
    int n, m;
    cin >> n >> m;
    // Enter the number of nodes
    // Enter the number of edges
    for (int i = 0; i < N; i++)
    {
        vis[i] = false;
    }
    for (int i = 0; i < m; i++)
    {
        int x, y;
        cin >> x >> y;

        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    queue<int> q;
    q.push(1);
    vis[1] = true;
    // We start with the source node 0
    vector<int>::iterator it;

    while (q.empty() == false)
    {
        int node = q.front();
        q.pop();
        cout << node << " ";
        for (it = adj[node].begin(); it != adj[node].end(); it++)
        {
            if (vis[*it] == false)
            {
                q.push(*it);
                vis[*it] = true;
            }
        }
    }
}
