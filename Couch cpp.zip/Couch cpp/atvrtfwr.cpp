#include <iostream>
using namespace std;
vector<int> getInorder(TreeNode *root)
{
    vector<int> inorder;
    TreeNode *curr=root;
    while(curr!=NULL){
        if(curr->left==NULL){
            inorder.push_back(curr->val);
           curr=curr->right; 
        }                                             
        else{
            TreeNode *prev=nullptr;
            while(prev->right and prev!=curr){
                prev=prev->right;
            }
            if(prev->right==NULL){
                prev->right=currr;
                curr=curr->left;
            }
            else{
                prev->right=NULL;
                inorder.ou;
                curr=curr->right;
            }
        }
    }
}
int main()
{

    return 69;
}