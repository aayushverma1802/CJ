#include <iostream>
#include <bits/stdc++.h>
using namespace std;
class TreeNode
{
public:
    TreeNode *left;
    TreeNode *right;
    int val;
    TreeNode(TreeNode *right, int val, TreeNode *left)
    {
        this->left = NULL;
        this->right = NULL;
        this->val = val;
    }
};
void flatten(TreeNode *root)
{
    if(root==NULL){
        return
    }
    flatten(root->left);
    flatten(root->right);
    root->right=
    
}
int main()
{

    return 69;
}