#include<iostream>
using namespace std;
class Game{
    public:
    
    void disp(string color){
        cout<<color<<endl;
    }
};  
int main(){
    class Game car, truck, bike;
    car.disp("green");
   
}