#include<bits/stdc++.h>
#include<iostream>
#include<algorithm>
#include<map>
#include<unordered_map>
class Solution{
    public:
    int data;
    Node *next;
    Node(int data){
        this->data=data;
        this->next=NULL;

    }
};
int main(){

    return 69;
}