#include <iostream>
using namespace std;
int main()
{
    int n;
    cin >> n;
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        int m;
        cin >> m;
        arr[i] = m;
    }
    bool ans=0;
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 1; j < n; j++)
        {
            if (arr[i] == arr[j])
            {
                ans=true;
            }

        }
    }
    if(ans==1){
        cout<<"True";
    }
    else{
        cout<<"False";
    }
}