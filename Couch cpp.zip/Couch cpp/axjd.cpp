#include<iostream>
using namespace std;
class Node{
    public:
    int data;
    Node *left;
    Node *right;
    Node(int data){
        this->data=data;
        this->left=NULL;
        this->right=NULL;
    }
    void preOrder(Node *ptr){
        if(ptr ==NULL){
            return;
        }
        preOrder(ptr->left);
        preOrder(ptr->right);
        cout<<ptr->data<<" ";
    }

};
bool isBST(Node *n){
    while(n!=NULL){
        Node *prev=NULL;
        if(!isBST(n->left)){
            return false;
        }
        if(prev!=NULL and prev->data >n->data){
        return false ;
        }
        prev=n;
        return isBST(n->right);

    }
}
int main(){
    Node *n=new Node(1);
    n->left=new Node (2);
    n->right=new Node(3);
    n->left->left=new Node (4);
    n->left->right=new Node  (5);
    n->preOrder(n);

}
