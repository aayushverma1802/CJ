#include<vector>
#include<iostream>
#include<set>
using namespace std;
const int inf=1e7;
int main(){
    int n,m;
    vector<int>dis(n+1,inf);
    vector<vector<pair<int,int>>>graph(n+1);

}