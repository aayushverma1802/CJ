#include <iostream>
#include <map>
#include <vector>
using namespace std;
int main()
{
    map<int, int> m;
    int arr[] = {-2, 2, -1, -5, 4, 0};
    int n = sizeof(arr) / sizeof(arr[0]);

    for (int i = 0; i < n; i++)
    {
        if (i % 2 == 0)
        {
            m.insert({i, arr[i]});
        }
    }

    for (auto i : m)
    {
        arr[i.first] = i.second;
    }
    for (int k = 0; k < n; k++)
    {
        printf("%d ", arr[k]);
    }
    return 0;
}
