#include <iostream>
using namespace std;
void bubble_Sort(int arr[], int n)
{
    for (int i = 0; i <= n - 1; i++)
    {
        for (int j = 0; j < n - 1 - i; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}
void ofr(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
}
// void insertion_sort(int arr[],int n){

// }
void selection_Sort(int arr[], int n)
{
    for (int i = 1; i <n; i++)
    {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 and arr[j] > key)
        {
            arr[j+1]=arr[j];

            j--;
        }
        arr[j+1] = key;
    }
}
void selection( int arr[],int n){
    for(int i=0;i<n-1;i++){
        int index_min=i;
        for(int j=i+1;j<n;j++){
            if(arr[j]<arr[index_min]){
                index_min=j;
            }
        }
        int temp=arr[i];
        arr[i]=arr[index_min];
        arr[index_min]=temp;
    }
}
int main()
{
    int arr[] = {
        50,
        30,
        10,
        20,
        40,
    };
    int n = sizeof(arr) / sizeof(arr[0]);
    selection_Sort(arr, n);
    ofr(arr, n);
}