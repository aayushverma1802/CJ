#include<iostream>
using namespace std;
int main(){
    int arr[3]={12,34,56};
    //User input
    int n;
    cin>>n;
//Insertion
    for(int i=0;i<n;i++){
        int val;
        cin>>val;
        arr[i]=val;
    }
//Traverse
for(int i=0;i<n;i++){
    cout<<arr[i]<<endl;
}
    return 0;
}