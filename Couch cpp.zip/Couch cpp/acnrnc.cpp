#include <iostream>
using namespace std;
class Heap
{
public:
    int size;
    int arr[100];
    Heap()
    {
        arr[0] = -1;
        size = 0;
    }
    void insertion(int data){
        size++;
        int index=size;
        arr[index]=data;
        while(index>1){
            int parent =index/2;
            if(arr[parent]<arr[index]){
                swap(arr[parent],arr[index]);
                index=parent;
            }else{
                return;
            }
        }
    }
    void print(){
        for(int i=1;i<=size;i++){
            cout<<arr[i]<<" ";
        }cout<<endl;
    }
    void deletefromHeap(){
        if(size==0){
            cout<<"Nothing to delete";
            return ;
        }
        arr[i]=arr[size];
        size--;
        int i=1;
        while(i<size){
            int l=2*i;
            int r=2*i+1;
            if(l<size and arr[i]<arr[l]){
                i-led
            }else{
                i er
            }
        }
    }
};