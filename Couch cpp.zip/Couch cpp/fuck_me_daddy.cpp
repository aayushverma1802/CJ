#include<iostream>
using namespace std;
class Node{
    public:
    int data;
    Node *next;
    Node (int data){
        this->data=data;
        next=NULL;
    }

};
int main(){
    class Node n(234);
    return 0;

}