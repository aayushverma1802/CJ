#include <stdio.h>
#include<stdlib.h>

//using namespace std;
struct  Node
{
//public:
    int size;
    int top;
    char *arr;
};
int isFull(struct Node *ptr)
{
    if (ptr->top == ptr->size - 1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
int isEmpty(struct Node *ptr)
{
    if (ptr->top == -1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
void push(struct Node *ptr, char data)
{
    if (!isFull(ptr))
    {
        ptr->top++;
        ptr->arr[ptr->top] = data;
    }
    else
    {
        printf( "Stack Overflow\n");
    }
}
void pop(struct Node *ptr)
{
    if (isEmpty(ptr))
    {
        printf( "Stack Underflow\n");
    }
    else
    {
        ptr->top--;
    }
}
int match(char *exp)
{
    struct Node *n;
    n->size = 80;
    n->top = -1;
    n->arr = (char *)malloc(sizeof(char) * n->size);
    for (int i = 0; i != '\0'; i++)
    {
        if (exp[i] == '(')
        {
            push(n, '(');
        }
        else if (exp[i] == ')')
        {
            if (isEmpty(n))
            {
                return 0;
            }
            pop(n);
        }
    }
    if (isEmpty(n))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
int main()
{
    char *exp = "(8*(9)";
    printf("%d ",(match(exp)));
   // return 0;
}