#include <iostream>
#include <queue>
#include <vector>
#include <bits/stdc++.h>
using namespace std;
class Solution
{
public:
    int orangesRotting(vector<vector<int>> &grid)
    {
        int n = grid.size();
        int m = grid[0].size();
        queue<pair<int, pair<int, int>>> q;

        vector<vector<bool>> vis(n, vector<bool>(m, false));
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
            {
                if (vis[i][j] == false and grid[i][j] == 2][=\\]
                {
                    vis[i][j] = true;
                    grid[i][j] = 2;
                    q.push({i,{j, 0}});
                }
            }
        }
        int delrow[] = {0, 0, -1, 1};
        int delcol[] = {-1, 1, 0, 0};
        int t = 0;
        while (q.empty() == false)
        {
            int row = q.front().first;
            int col = q.front().second.first;
            int time=q.front().second.second;
            q.pop();
            for (int i = 0; i < 4; i++)
            {
                int crow = row + delrow[i];
                int ccol = col + delcol[i];
                if (crow < n and ccol < m and crow >= 0 and ccol >= 0 and vis[crow][ccol] == false and grid[crow][ccol] == 1)
                {
                    vis[crow][ccol] = true;
                    grid[crow][ccol]=2;
                    q.push({crow, {ccol, time + 1}});
                }
            }
        }
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; i < m; j++)
            {
                if (vis[i][j] == false and grid[i][j] == 1)
                {
                    return -1;
                }
            }
        }
    }
};
int main()
{

    return 69;
}