
class Solution
{
public:
    bool isPalindrome(string s)
    {
        vector<char> ans, temp;
        for (int i = 0; i < s.size(); i++)
        {
            if ((s[i] >= 'a' and s[i] <= 'z') or (s[i] >= 'A' and s[i] <= 'Z' or (s[i] >= '0' and s[i] <= '9')))
            {
                temp.push_back(tolower(s[i]));
            }
        }
        ans = temp;
        reverse(ans.begin(), ans.end());
        return temp == ans;
    }
};