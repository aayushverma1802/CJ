#include<iostream>
using namespace std;
class heap{
    public:
    int arr[100];
    int size=0;
    void insert(int data){
         
    }

};
int main(){

    return 69;
}