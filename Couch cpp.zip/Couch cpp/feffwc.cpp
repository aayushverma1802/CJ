#include<iostream>
using namespace std;
int main(){
    int n=24;
    //Left shift of the number n;
    //shift by 1;
    cout<<(n<<1)<<endl;
    //Right shift of the number n;
    //shift by 1;
    cout<<(n>>1)<<endl;

    cout<<"AND "<<(25&&9)<<endl;
    cout<<"NOR "<<(~9)<<endl;
    cout<<"XOR "<<(25^9)<<endl;
    cout<<"OR "<<(25|9)<<endl;

    return 0;
}