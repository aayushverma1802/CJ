#include <iostream>
using namespace std;
void print(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }
}
int main()
{
    int arr[] = {12, 54, 65, 7, 25, 9};
    int n = sizeof(arr) / sizeof(arr[0]);
    adaptive_Bubble_Sort(arr, n);
    print(arr, n);
}
void bubble_Sort(int arr[], int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - 1 - i; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}
void adaptive_Bubble_Sort(int arr[], int n)
{
    int isSorted = 0;
    for (int i = 0; i < n; i++)
    {
        isSorted = 1;
        for (int j = 0; j < n - 1 - i; j++)
        {

            if (arr[j] > arr[j + 1])
            {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
            isSorted = 0;
        }
        if (isSorted == 1)
        {
            return;
        }
    }
}
void insertion_Sort(int arr[], int n)
{
    int j;
    int key;
    for (int i = 1; i <= n - 1; j++)
    {
        key = arr[i];
        j = i - 1;
        while (j >= 0 and arr[j] > key)
        {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}
void insertion_Sort(int arr[], int n)
{
    int j, key;
    for (int i = 0; i < n; i++)
    {
        j = i - 1;
        key = a[i];
        while (j >= 0 and arr[j] > key)
        {
            a[j + 1] = a[j];
        }
        a[j + 1] = key;
    }
}
void selection int main()
{
    int arr[] = {12, 54, 65, 7, 25, 9};
    int n = sizeof(arr) / sizeof(arr[0]);
    adaptive_Bubble_Sort(arr, n);
    print(arr, n);
}