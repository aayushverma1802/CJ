#include<stdio.h>
#include<stdlib.h>
struct Node{
    int data;
    struct Node *left;
    struct Node *right;

};
struct Node *createNode(int data){
    struct Node *n=(struct Node *)malloc(sizeof(struct Node));
    n->data;
    n->left=NULL;
    n->right=NULL;

}
void Inorder(struct Node *root){
    if(root!=NULL){
        Inorder(root->left);
        printf("%d ",root->data );
        Inorder(root->right);
    }
}
int isBST(struct Node  *root){
    static struct Node *prev=NULL;
    if(root==NULL){
        return 1;
    }
    else{
        if(!isBST(root->left)){
            return 0;
        }
        if(prev!=NULL && prev->data>=root->data ){
            return 0;

        }
        prev =root ;
        isBST(root->right);
    }
}

void insert(struct Node *root,int key ){
    struct Node *prev=NULL;
    while(root!=NULL){
        prev=root;
        if(key==root->data){
            printf("Cannot insert the element\n");
            return ;
        }
        else if(key<root->data){
            root=root->left;

        }
        else{
            root=root->right;
        }
    }
    struct Node *new =createNode(key);
    if(key<prev->data){
        prev->left=new;

    }
    else{
        prev->right=new;
    }
}
void insertt(struct Node *root,int key){
    struct Node *prev=NULL;
    while(root!=NULL){
        prev=root;
        if(key==root->data){
            printf("Cannot insert the element\n");
            return ;


        }
        else if(root->data>key){
            root=root->left;
        }
        else{
            root=root->right;
        }

    }
    struct Node *new=createNode (key);
    if(key<prev->data){
        prev->left=new;

    }
    else{
        prev->right=new;
    }
}
int main(){

    return 69;
}