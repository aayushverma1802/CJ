#include<iostream>
using namespace std;
class Node{
    public:
    int data;
    Node *next;
    Node(int data){
        this->data=data;
        this->next=NULL;
    }
    Node *front(Node *h,int data){

    }

};

int main(){
    Node *obj;
    Node *n=new Node(23);
    obj->data


    return 69;
}