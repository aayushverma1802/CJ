class Solution{
    void solve(vector<vector<char>>&board){
        int n=board.size();
        int m=board[0].size();
        vector<vector<int>>vis(n,vector<int>(m,0));
        //traveres the first row and the first column
        for(int i=0;i<n;i++){
            if(vis[i][0]==false and board[i][0]=='0'){
                dfs();
            }
            if(vis[n-1])
        }
        
    }
}