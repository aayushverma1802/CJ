#include<iostream>
#include<vector>
using namespace std;
int main(){
    inta;cin>>a;
    //Take the input for the following 
    return 0;
}