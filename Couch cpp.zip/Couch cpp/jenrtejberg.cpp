#include<iostream>
#include<queue>
using namespace std;
int main(){
    deque<int>q;
    q.push_back(34);
    q.push_front(24);
    //to make the use of the stack using the queue operation in a single queue 
    //i may use the dequeue operation to solve the o(1) operations hence making it in
    //o(n) using the complexities
    cout<<q.front();
  cout<<  q.end ();

    
    return 69;

}