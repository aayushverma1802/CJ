#include<iostream>
#include<string.h>
using namespace std;

int main(){
    string s,s1;
    s="Hello";
    s1=" Ji";
    // s=s+s1;
    s.append(s1);
    cout<<s;

}